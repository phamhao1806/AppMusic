package com.example.app_music2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
