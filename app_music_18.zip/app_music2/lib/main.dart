import 'package:flutter/cupertino.dart';
import 'package:app_music2/ui/home/home.dart';

void main() => runApp(const MusicApp());